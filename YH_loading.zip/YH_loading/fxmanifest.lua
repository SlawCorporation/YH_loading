fx_version 'cerulean'
game 'gta5'

client_script 'client.lua'

loadscreen_cursor 'yes'
loadscreen 'html/index.html'

files {
    'html/index.html',
    'html/assets/**/*.*',
    'html/assets/**/**/*.*'
}