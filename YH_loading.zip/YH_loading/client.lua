--Leak-By-FOCUS#5908--

Citizen.CreateThread(function()
    ShutdownLoadingScreenNui()
    ShutdownLoadingScreen()
end)

print('Leak-By-FOCUS#5908')